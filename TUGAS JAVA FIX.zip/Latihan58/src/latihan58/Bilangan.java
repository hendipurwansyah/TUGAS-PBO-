/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package latihan58;

/**
 *
 * @author DADAR GULUNG JUMBO
 */
public class Bilangan {
    private int x;
    private int y;
    
    public Bilangan(){
        x = 3;
        y = 4;
                
    }
    
    public int getX(){
        return x;
    }
    
    public int getY(){
        return y;
    }

}
