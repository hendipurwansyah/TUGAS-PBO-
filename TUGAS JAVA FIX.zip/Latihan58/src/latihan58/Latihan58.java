/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package latihan58;

/**
 *
 * @author DADAR GULUNG JUMBO
 */
public class Latihan58 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        JumlahBilangan jml = new JumlahBilangan();
        jml.tampilHasilJumlah();
        SelisihBilangan slb = new SelisihBilangan();
        slb.tampilSelisih();
        
    }
    
}
