/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package latihan58;

/**
 *
 * @author DADAR GULUNG JUMBO
 */
public class SelisihBilangan extends Bilangan {
    public void tampilSelisih(){
        int a,b;
        a=getX();
        b=getY();
        System.out.println("Hasil selisih 3-4 = "+(a-b));
    }
}
