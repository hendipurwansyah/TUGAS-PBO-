/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package latihan.pkg54;

/**
 *
 * @author DADAR GULUNG JUMBO
 */
public class Latihan54 {

    public static void main(String[] args) {
        // TODO code application logic here
      WarnaKoordinat Latihan54 = new WarnaKoordinat("jingga",10,4);
      System.out.println("Warna Koordinat :"+Latihan54.getNamaWarna());
      System.out.println("Koordinat sumbu x :"+Latihan54.getX()+", y :"+Latihan54.getY());
      
    }
      
      
      
      
    
}
