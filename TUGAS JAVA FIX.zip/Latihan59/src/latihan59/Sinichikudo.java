/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package latihan59;

/**
 *
 * @author DADAR GULUNG JUMBO
 */
public class Sinichikudo extends conan {

String karakter;

public Sinichikudo(){
    
}
public String getKarakter(){
    return karakter;
}
public void setKarakter(String karakter){
    this.karakter = karakter ;
}


    
}
