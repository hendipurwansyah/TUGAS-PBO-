/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package latihan59;

/**
 *
 * @author DADAR GULUNG JUMBO
 */
public class gin extends conan{
        String karakter4;

public gin(){
    
}
public String getKarakter4(){
    return karakter4;
}
public void setKarakter4(String karakter4){
    this.karakter4 = karakter4 ;
}
    
}
