/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package latihan60;

/**
 *
 * @author DADAR GULUNG JUMBO
 */
public class sasori extends akatsuki {
    String katakatamutiara3;
    String kekuatan3;

public sasori(){
    
}
public String getkatakatamutiara3(){
    return katakatamutiara3;
}
public void setkatakatamutiara3(String katakatamutiara3){
    this.katakatamutiara3 = katakatamutiara3;
}
public String getkekuatan3(){
    return kekuatan3;
}
public void setkekuatan3(String kekuatan3){
    this.kekuatan3 = kekuatan3;
}
}
    

