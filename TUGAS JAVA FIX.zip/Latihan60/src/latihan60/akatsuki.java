/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package latihan60;

/**
 *
 * @author DADAR GULUNG JUMBO
 */
public class akatsuki {
    String namatokoh;

public akatsuki(){
    
}
public String getnamatokoh(){
    return namatokoh;
}
public void setnamatokoh(String namatokoh){
    this.namatokoh = namatokoh;
}

}
