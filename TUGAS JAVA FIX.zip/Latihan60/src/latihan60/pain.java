/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package latihan60;

/**
 *
 * @author DADAR GULUNG JUMBO
 */
public class pain extends akatsuki {
    String katakatamutiara;
    String kekuatan;

public pain(){
    
}
public String getkatakatamutiara(){
    return katakatamutiara;
}
public void setkatakatamutiara(String katakatamutiara){
    this.katakatamutiara = katakatamutiara;
}
public String getkekuatan(){
    return kekuatan;
}
public void setkekuatan(String kekuatan){
    this.kekuatan = kekuatan;
}
}
